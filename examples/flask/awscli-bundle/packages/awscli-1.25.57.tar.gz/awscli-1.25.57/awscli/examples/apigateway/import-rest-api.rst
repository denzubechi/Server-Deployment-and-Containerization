**To import a Swagger template and create an API**

Command::

  aws apigateway import-rest-api --body 'file:///path/to/API_Swagger_template.json'
